

import React, { useState, useEffect, useCallback, useMemo } from 'react';
import type { User, Document, Version, Activity, Page } from './types';
import * as geminiService from './services/geminiService';

// Mock Data
const MOCK_USERS: User[] = [
  { id: 'user-1', email: 'admin@example.com', name: 'Admin Alice', role: 'admin' },
  { id: 'user-2', email: 'user@example.com', name: 'User Bob', role: 'user' },
];

const MOCK_DOCS: Document[] = [
  {
    id: 'doc-1',
    title: 'Q3 Marketing Strategy',
    content: 'Our main focus for Q3 will be on digital channels. We will launch a new social media campaign targeting Gen Z on platforms like TikTok and Instagram. The budget allocated is $50,000. Key metrics for success will be engagement rate and conversion to trial sign-ups.',
    summary: 'Q3 marketing focuses on a $50k social media campaign targeting Gen Z on TikTok and Instagram to drive engagement and trial sign-ups.',
    tags: ['marketing', 'q3', 'strategy', 'social-media'],
    createdBy: 'user-1',
    authorName: 'Admin Alice',
    createdAt: new Date('2023-08-15T10:00:00Z'),
    updatedAt: new Date('2023-08-16T14:30:00Z'),
    history: [{ version: 1, createdAt: new Date('2023-08-15T10:00:00Z'), content: 'Initial content...' }],
  },
  {
    id: 'doc-2',
    title: 'Engineering Best Practices',
    content: 'All new code must be submitted via a pull request and requires at least one approval from a senior engineer. Code must be accompanied by unit tests with at least 80% coverage. Use Prettier for code formatting and ESLint for linting.',
    summary: 'Engineering standards require pull requests with senior approval, 80% unit test coverage, and adherence to Prettier and ESLint for code quality.',
    tags: ['engineering', 'code-quality', 'testing', 'guidelines'],
    createdBy: 'user-2',
    authorName: 'User Bob',
    createdAt: new Date('2023-08-20T11:00:00Z'),
    updatedAt: new Date('2023-08-20T11:00:00Z'),
    history: [{ version: 1, createdAt: new Date('2023-08-20T11:00:00Z'), content: 'Initial content...' }],
  },
];

const MOCK_ACTIVITY: Activity[] = [
    { docId: 'doc-1', docTitle: 'Q3 Marketing Strategy', user: 'Admin Alice', action: 'edited', timestamp: new Date('2023-08-16T14:30:00Z') },
    { docId: 'doc-2', docTitle: 'Engineering Best Practices', user: 'User Bob', action: 'created', timestamp: new Date('2023-08-20T11:00:00Z') },
];


// --- ICON COMPONENTS ---
const DocumentIcon: React.FC<{ className?: string }> = ({ className }) => (
  <svg xmlns="http://www.w3.org/2000/svg" className={className} fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 12h6m-6 4h6m2 5H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2 2z" /></svg>
);
const SearchIcon: React.FC<{ className?: string }> = ({ className }) => (
    <svg xmlns="http://www.w3.org/2000/svg" className={className} fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M21 21l-6-6m2-5a7 7 0 11-14 0 7 7 0 0114 0z" /></svg>
);
const QandAIcon: React.FC<{ className?: string }> = ({ className }) => (
    <svg xmlns="http://www.w3.org/2000/svg" className={className} fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M8 12h.01M12 12h.01M16 12h.01M21 12c0 4.418-4.03 8-9 8a9.863 9.863 0 01-4.255-.949L3 20l1.395-3.72C3.512 15.042 3 13.574 3 12c0-4.418 4.03-8 9-8s9 3.582 9 8z" /></svg>
);
const SparklesIcon: React.FC<{ className?: string }> = ({ className }) => (
    <svg xmlns="http://www.w3.org/2000/svg" className={className} fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 3v4M3 5h4M6.343 6.343l1.414 1.414m10.286-2.828l-1.414 1.414M21 12h-4m2 2l-1.414 1.414M12 21v-4m-2 2h4m-7.657-7.657l-1.414-1.414M6.343 17.657l1.414-1.414" /></svg>
);
const PlusIcon: React.FC<{ className?: string }> = ({ className }) => (
    <svg xmlns="http://www.w3.org/2000/svg" className={className} fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 6v6m0 0v6m0-6h6m-6 0H6" /></svg>
);
const EditIcon: React.FC<{ className?: string }> = ({ className }) => (
    <svg xmlns="http://www.w3.org/2000/svg" className={className} fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}><path strokeLinecap="round" strokeLinejoin="round" d="M15.232 5.232l3.536 3.536m-2.036-5.036a2.5 2.5 0 113.536 3.536L6.5 21.036H3v-3.5L15.232 5.232z" /></svg>
);
const DeleteIcon: React.FC<{ className?: string }> = ({ className }) => (
    <svg xmlns="http://www.w3.org/2000/svg" className={className} fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}><path strokeLinecap="round" strokeLinejoin="round" d="M19 7l-.867 12.142A2 2 0 0116.138 21H7.862a2 2 0 01-1.995-1.858L5 7m5 4v6m4-6v6m1-10V4a1 1 0 00-1-1h-4a1 1 0 00-1 1v3M4 7h16" /></svg>
);
const HistoryIcon: React.FC<{ className?: string }> = ({ className }) => (
    <svg xmlns="http://www.w3.org/2000/svg" className={className} fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}><path strokeLinecap="round" strokeLinejoin="round" d="M12 8v4l3 3m6-3a9 9 0 11-18 0 9 9 0 0118 0z" /></svg>
);


// --- UI HELPER COMPONENTS ---
const Spinner: React.FC = () => (
    <div className="animate-spin rounded-full h-5 w-5 border-b-2 border-white"></div>
);

interface ModalProps {
    isOpen: boolean;
    onClose: () => void;
    title: string;
    children: React.ReactNode;
}
const Modal: React.FC<ModalProps> = ({ isOpen, onClose, title, children }) => {
    if (!isOpen) return null;
    return (
        <div className="fixed inset-0 bg-black bg-opacity-70 flex items-center justify-center z-50 transition-opacity duration-300" onClick={onClose}>
            <div className="bg-gray-800 rounded-lg shadow-2xl p-6 w-full max-w-2xl transform transition-all duration-300 scale-95 hover:scale-100" onClick={(e) => e.stopPropagation()}>
                <div className="flex justify-between items-center border-b border-gray-700 pb-3 mb-4">
                    <h2 className="text-xl font-bold text-white">{title}</h2>
                    <button onClick={onClose} className="text-gray-400 hover:text-white">&times;</button>
                </div>
                {children}
            </div>
        </div>
    );
};


// --- PAGE COMPONENTS & LAYOUT ---

const LoginPage: React.FC<{ onLogin: (user: User) => void }> = ({ onLogin }) => {
    const [email, setEmail] = useState('');
    const handleSubmit = (e: React.FormEvent) => {
        e.preventDefault();
        const user = MOCK_USERS.find(u => u.email.toLowerCase() === email.toLowerCase().trim());
        if (user) {
            onLogin(user);
        } else {
            alert('User not found. Try "admin@example.com" or "user@example.com".');
        }
    };
    return (
        <div className="min-h-screen flex items-center justify-center bg-gray-900">
            <div className="w-full max-w-md p-8 space-y-8 bg-gray-800 rounded-lg shadow-lg">
                <div className="text-center">
                    <h1 className="text-4xl font-extrabold text-white">Gemini Knowledge Hub</h1>
                    <p className="mt-2 text-gray-400">Log in to collaborate</p>
                </div>
                <form className="space-y-6" onSubmit={handleSubmit}>
                    <div>
                        <label htmlFor="email" className="text-sm font-bold text-gray-300 block mb-2">Email Address</label>
                        <input
                            id="email"
                            name="email"
                            type="email"
                            autoComplete="email"
                            required
                            value={email}
                            onChange={(e) => setEmail(e.target.value)}
                            className="w-full px-3 py-2 bg-gray-700 border border-gray-600 rounded-md text-white focus:outline-none focus:ring-2 focus:ring-teal-500"
                            placeholder="admin@example.com"
                        />
                    </div>
                    <button type="submit" className="w-full py-2 px-4 bg-teal-600 hover:bg-teal-700 rounded-md text-white font-semibold transition-colors">Sign In</button>
                </form>
            </div>
        </div>
    );
};


const Header: React.FC<{ user: User; onLogout: () => void; onNavigate: (page: Page) => void }> = ({ user, onLogout, onNavigate }) => (
    <header className="bg-gray-800/50 backdrop-blur-sm sticky top-0 z-40 shadow-md">
        <div className="container mx-auto px-4 sm:px-6 lg:px-8">
            <div className="flex items-center justify-between h-16">
                <div className="flex items-center space-x-4">
                    <SparklesIcon className="h-8 w-8 text-teal-400" />
                    <h1 className="text-2xl font-bold text-white">Knowledge Hub</h1>
                </div>
                <div className="flex items-center space-x-4">
                     <p className="text-gray-300 hidden sm:block">Welcome, <span className="font-semibold text-white">{user.name}</span></p>
                     <button onClick={onLogout} className="px-4 py-2 bg-gray-700 hover:bg-red-600 rounded-md text-sm font-medium transition-colors">Logout</button>
                </div>
            </div>
        </div>
    </header>
);

const AppLayout: React.FC<{ user: User; onLogout: () => void; onNavigate: (page: Page) => void; activePage: Page; children: React.ReactNode; }> = ({ user, onLogout, onNavigate, activePage, children }) => (
    <div className="min-h-screen bg-gray-900">
        <Header user={user} onLogout={onLogout} onNavigate={onNavigate} />
        <div className="container mx-auto px-4 sm:px-6 lg:px-8 py-8 flex">
             <nav className="w-56 flex-shrink-0 pr-8">
                <div className="space-y-2">
                    <button onClick={() => onNavigate('dashboard')} className={`w-full flex items-center px-4 py-2 rounded-md text-left transition-colors ${activePage === 'dashboard' ? 'bg-teal-600 text-white' : 'hover:bg-gray-700'}`}>
                        <DocumentIcon className="h-5 w-5 mr-3" /> Dashboard
                    </button>
                    <button onClick={() => onNavigate('search')} className={`w-full flex items-center px-4 py-2 rounded-md text-left transition-colors ${activePage === 'search' ? 'bg-teal-600 text-white' : 'hover:bg-gray-700'}`}>
                        <SearchIcon className="h-5 w-5 mr-3" /> Search
                    </button>
                    <button onClick={() => onNavigate('qa')} className={`w-full flex items-center px-4 py-2 rounded-md text-left transition-colors ${activePage === 'qa' ? 'bg-teal-600 text-white' : 'hover:bg-gray-700'}`}>
                        <QandAIcon className="h-5 w-5 mr-3" /> Team Q&A
                    </button>
                </div>
             </nav>
            <main className="flex-1 min-w-0">
                {children}
            </main>
        </div>
    </div>
);


// --- APP ---

function App() {
  const [user, setUser] = useState<User | null>(null);
  const [page, setPage] = useState<Page>('dashboard');
  
  const [documents, setDocuments] = useState<Document[]>(MOCK_DOCS);
  const [activities, setActivities] = useState<Activity[]>(MOCK_ACTIVITY);

  const [editingDocument, setEditingDocument] = useState<Document | null>(null);
  
  const [isLoading, setIsLoading] = useState(false);
  const [historyModalOpen, setHistoryModalOpen] = useState(false);
  const [selectedDocForHistory, setSelectedDocForHistory] = useState<Document | null>(null);

  // Auth
  const handleLogin = (loggedInUser: User) => {
    setUser(loggedInUser);
    setPage('dashboard');
  };
  const handleLogout = () => setUser(null);

  // Navigation
  const handleNavigate = (targetPage: Page) => setPage(targetPage);

  const handleStartEdit = (doc: Document | null) => {
    setEditingDocument(doc);
    setPage('edit');
  };

  // Document CRUD
  const handleSaveDocument = async (title: string, content: string) => {
    if (!user) return;
    setIsLoading(true);

    const isNew = !editingDocument;
    try {
        const [summary, tags] = await Promise.all([
            geminiService.summarizeText(content),
            geminiService.generateTags(content)
        ]);
        
        if (isNew) {
            const newDoc: Document = {
                id: `doc-${Date.now()}`,
                title,
                content,
                summary,
                tags,
                createdBy: user.id,
                authorName: user.name,
                createdAt: new Date(),
                updatedAt: new Date(),
                history: [{ version: 1, createdAt: new Date(), content }],
            };
            setDocuments(prev => [newDoc, ...prev]);
            setActivities(prev => [{ docId: newDoc.id, docTitle: newDoc.title, user: user.name, action: 'created', timestamp: new Date() }, ...prev]);
        } else {
            setDocuments(prev => prev.map(doc => {
                if (doc.id === editingDocument.id) {
                    const newVersion = doc.history.length + 1;
                    return {
                        ...doc,
                        title,
                        content,
                        summary,
                        tags,
                        updatedAt: new Date(),
                        history: [...doc.history, { version: newVersion, createdAt: new Date(), content }],
                    };
                }
                return doc;
            }));
            setActivities(prev => [{ docId: editingDocument.id, docTitle: title, user: user.name, action: 'edited', timestamp: new Date() }, ...prev]);
        }
        setPage('dashboard');
    } catch(err) {
        console.error("Failed to save document:", err);
        alert("An error occurred while saving the document.");
    } finally {
        setIsLoading(false);
        setEditingDocument(null);
    }
  };

  const handleDeleteDocument = (docId: string) => {
    if (window.confirm("Are you sure you want to delete this document?")) {
        setDocuments(prev => prev.filter(d => d.id !== docId));
    }
  };

  // AI Actions
  const handleAISummarize = async (docId: string) => {
    const doc = documents.find(d => d.id === docId);
    if (!doc) return;
    setIsLoading(true);
    const summary = await geminiService.summarizeText(doc.content);
    setDocuments(prev => prev.map(d => d.id === docId ? { ...d, summary } : d));
    setIsLoading(false);
  };

  const handleAIGenerateTags = async (docId: string) => {
    const doc = documents.find(d => d.id === docId);
    if (!doc) return;
    setIsLoading(true);
    const tags = await geminiService.generateTags(doc.content);
    setDocuments(prev => prev.map(d => d.id === docId ? { ...d, tags } : d));
    setIsLoading(false);
  };
  
  // History
  const handleShowHistory = (doc: Document) => {
    setSelectedDocForHistory(doc);
    setHistoryModalOpen(true);
  };

  // --- Render Logic ---
  if (!user) {
    return <LoginPage onLogin={handleLogin} />;
  }
  
  const renderPage = () => {
    switch (page) {
      case 'dashboard':
        return <DashboardPage user={user} documents={documents} activities={activities} onNewDoc={() => handleStartEdit(null)} onEdit={handleStartEdit} onDelete={handleDeleteDocument} onShowHistory={handleShowHistory} onSummarize={handleAISummarize} onGenerateTags={handleAIGenerateTags} />;
      case 'edit':
        return <DocumentEditorPage doc={editingDocument} onSave={handleSaveDocument} onCancel={() => setPage('dashboard')} isLoading={isLoading} />;
      case 'search':
        return <SearchPage documents={documents} />;
      case 'qa':
        return <TeamQAPage documents={documents} />;
      default:
        return <div>Page not found</div>;
    }
  };

  return (
    <>
      <AppLayout user={user} onLogout={handleLogout} onNavigate={handleNavigate} activePage={page}>
        {renderPage()}
      </AppLayout>
      <Modal isOpen={historyModalOpen} onClose={() => setHistoryModalOpen(false)} title={`History for "${selectedDocForHistory?.title}"`}>
        {selectedDocForHistory && <VersionHistory history={selectedDocForHistory.history} />}
      </Modal>
    </>
  );
}


// --- DASHBOARD COMPONENTS ---
const DocumentCard: React.FC<{ doc: Document; user: User; onEdit: (doc: Document) => void; onDelete: (id: string) => void; onShowHistory: (doc: Document) => void; onSummarize: (id: string) => void; onGenerateTags: (id: string) => void; }> = ({ doc, user, onEdit, onDelete, onShowHistory, onSummarize, onGenerateTags }) => {
    const canEdit = user.role === 'admin' || user.id === doc.createdBy;
    return (
        <div className="bg-gray-800 rounded-lg shadow-lg p-5 flex flex-col justify-between transition-transform transform hover:-translate-y-1">
            <div>
                <h3 className="text-xl font-bold text-white mb-2">{doc.title}</h3>
                <p className="text-gray-400 text-sm mb-3">By {doc.authorName} on {doc.createdAt.toLocaleDateString()}</p>
                <p className="text-gray-300 mb-4 text-sm">{doc.summary}</p>
                <div className="flex flex-wrap gap-2 mb-4">
                    {doc.tags.map(tag => (
                        <span key={tag} className="bg-teal-900 text-teal-300 text-xs font-medium px-2.5 py-0.5 rounded-full">{tag}</span>
                    ))}
                </div>
            </div>
            <div className="border-t border-gray-700 pt-3 flex flex-wrap items-center justify-between gap-2">
                <div className="flex gap-2">
                    <button onClick={() => onSummarize(doc.id)} className="text-xs px-2 py-1 bg-gray-700 hover:bg-blue-600 rounded flex items-center gap-1"><SparklesIcon className="h-4 w-4" /> Summarize</button>
                    <button onClick={() => onGenerateTags(doc.id)} className="text-xs px-2 py-1 bg-gray-700 hover:bg-purple-600 rounded flex items-center gap-1"><SparklesIcon className="h-4 w-4" /> Gen Tags</button>
                    <button onClick={() => onShowHistory(doc)} className="text-xs px-2 py-1 bg-gray-700 hover:bg-gray-600 rounded flex items-center gap-1"><HistoryIcon className="h-4 w-4" /> History</button>
                </div>
                {canEdit && (
                    <div className="flex gap-2">
                        <button onClick={() => onEdit(doc)} className="text-xs p-2 bg-gray-700 hover:bg-yellow-600 rounded"><EditIcon className="h-4 w-4" /></button>
                        <button onClick={() => onDelete(doc.id)} className="text-xs p-2 bg-gray-700 hover:bg-red-600 rounded"><DeleteIcon className="h-4 w-4" /></button>
                    </div>
                )}
            </div>
        </div>
    );
};

const ActivityFeed: React.FC<{ activities: Activity[] }> = ({ activities }) => (
    <div className="w-64 flex-shrink-0 ml-8 hidden lg:block">
        <h3 className="text-lg font-semibold mb-4 text-white">Team Activity</h3>
        <ul className="space-y-4">
            {activities.slice(0, 5).map(activity => (
                <li key={`${activity.docId}-${activity.timestamp.toISOString()}`} className="text-sm">
                    <p className="font-semibold text-gray-300">{activity.user} <span className="font-normal text-gray-400">{activity.action}</span></p>
                    <p className="text-teal-400 truncate">{activity.docTitle}</p>
                    <p className="text-gray-500 text-xs">{activity.timestamp.toLocaleString()}</p>
                </li>
            ))}
        </ul>
    </div>
);

// FIX: Added onNewDoc to props, destructured it, and used it in the onClick handler.
const DashboardPage: React.FC<{ user:User, documents: Document[], activities: Activity[], onNewDoc: () => void } & Omit<React.ComponentProps<typeof DocumentCard>, 'doc' | 'user'>> = ({ user, documents, activities, onNewDoc, ...cardProps }) => {
    const [filterTags, setFilterTags] = useState<string[]>([]);
    const allTags = useMemo(() => Array.from(new Set(documents.flatMap(d => d.tags))), [documents]);

    const toggleTag = (tag: string) => {
        setFilterTags(prev => prev.includes(tag) ? prev.filter(t => t !== tag) : [...prev, tag]);
    };
    
    const filteredDocuments = useMemo(() => {
        if (filterTags.length === 0) return documents;
        return documents.filter(doc => filterTags.every(tag => doc.tags.includes(tag)));
    }, [documents, filterTags]);
    
    return (
        <div className="flex">
            <div className="flex-1">
                <div className="flex justify-between items-center mb-6">
                    <h2 className="text-3xl font-bold text-white">Documents</h2>
                    <button onClick={onNewDoc} className="px-4 py-2 bg-teal-600 hover:bg-teal-700 rounded-md text-white font-semibold flex items-center gap-2 transition-colors"><PlusIcon className="h-5 w-5"/> New Document</button>
                </div>
                <div className="mb-6 flex flex-wrap gap-2">
                    {allTags.map(tag => (
                        <button key={tag} onClick={() => toggleTag(tag)} className={`px-3 py-1 rounded-full text-sm transition-colors ${filterTags.includes(tag) ? 'bg-teal-500 text-white' : 'bg-gray-700 hover:bg-gray-600'}`}>{tag}</button>
                    ))}
                </div>
                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                    {filteredDocuments.map(doc => (
                        <DocumentCard key={doc.id} doc={doc} user={user} {...cardProps} />
                    ))}
                </div>
            </div>
            <ActivityFeed activities={activities} />
        </div>
    );
};


// --- OTHER PAGES ---
const DocumentEditorPage: React.FC<{ doc: Document | null, onSave: (title: string, content: string) => void, onCancel: () => void, isLoading: boolean }> = ({ doc, onSave, onCancel, isLoading }) => {
    const [title, setTitle] = useState(doc?.title || '');
    const [content, setContent] = useState(doc?.content || '');
    
    const handleSubmit = (e: React.FormEvent) => {
        e.preventDefault();
        onSave(title, content);
    };

    return (
        <div>
            <h2 className="text-3xl font-bold text-white mb-6">{doc ? 'Edit Document' : 'Create New Document'}</h2>
            <form onSubmit={handleSubmit} className="space-y-6">
                <div>
                    <label htmlFor="title" className="block text-sm font-medium text-gray-300 mb-1">Title</label>
                    <input type="text" id="title" value={title} onChange={(e) => setTitle(e.target.value)} required className="w-full bg-gray-800 rounded-md border-gray-700 px-3 py-2 focus:ring-teal-500 focus:border-teal-500" />
                </div>
                <div>
                    <label htmlFor="content" className="block text-sm font-medium text-gray-300 mb-1">Content</label>
                    <textarea id="content" value={content} onChange={(e) => setContent(e.target.value)} required rows={15} className="w-full bg-gray-800 rounded-md border-gray-700 px-3 py-2 focus:ring-teal-500 focus:border-teal-500"></textarea>
                </div>
                <div className="flex justify-end gap-4">
                    <button type="button" onClick={onCancel} className="px-4 py-2 bg-gray-600 hover:bg-gray-700 rounded-md">Cancel</button>
                    <button type="submit" disabled={isLoading} className="px-6 py-2 bg-teal-600 hover:bg-teal-700 rounded-md flex items-center gap-2 disabled:bg-gray-500">
                        {isLoading ? <><Spinner /> Saving...</> : 'Save'}
                    </button>
                </div>
            </form>
        </div>
    );
};

const SearchPage: React.FC<{ documents: Document[] }> = ({ documents }) => {
    const [query, setQuery] = useState('');
    const [searchResults, setSearchResults] = useState<Document[]>([]);
    const [isSearching, setIsSearching] = useState(false);

    const handleTextSearch = () => {
        if (!query) {
            setSearchResults([]);
            return;
        }
        setIsSearching(true);
        const lowerQuery = query.toLowerCase();
        const results = documents.filter(doc => 
            doc.title.toLowerCase().includes(lowerQuery) || 
            doc.summary.toLowerCase().includes(lowerQuery) || 
            doc.tags.some(tag => tag.toLowerCase().includes(lowerQuery))
        );
        setSearchResults(results);
        setIsSearching(false);
    };

    const handleSemanticSearch = async () => {
        if (!query) {
            setSearchResults([]);
            return;
        }
        setIsSearching(true);
        const results = await geminiService.semanticSearch(query, documents);
        setSearchResults(results);
        setIsSearching(false);
    };
    
    return (
        <div>
            <h2 className="text-3xl font-bold text-white mb-6">Search Documents</h2>
            <div className="flex gap-2 mb-6">
                <input type="text" value={query} onChange={e => setQuery(e.target.value)} placeholder="Search by keyword or concept..." className="flex-grow bg-gray-800 rounded-md border-gray-700 px-4 py-2 focus:ring-teal-500 focus:border-teal-500" />
                <button onClick={handleTextSearch} className="px-4 py-2 bg-gray-600 hover:bg-gray-700 rounded-md">Text Search</button>
                <button onClick={handleSemanticSearch} className="px-4 py-2 bg-teal-600 hover:bg-teal-700 rounded-md flex items-center gap-2"><SparklesIcon className="h-5 w-5" /> AI Search</button>
            </div>
            <div>
                {isSearching ? <div className="flex justify-center p-8"><Spinner /></div> : (
                    <div className="space-y-4">
                        {searchResults.map(doc => (
                            <div key={doc.id} className="bg-gray-800 p-4 rounded-md">
                                <h3 className="font-bold text-lg text-teal-400">{doc.title}</h3>
                                <p className="text-sm text-gray-300">{doc.summary}</p>
                            </div>
                        ))}
                    </div>
                )}
            </div>
        </div>
    );
};

const TeamQAPage: React.FC<{ documents: Document[] }> = ({ documents }) => {
    const [question, setQuestion] = useState('');
    const [answer, setAnswer] = useState('');
    const [isAsking, setIsAsking] = useState(false);

    const handleAsk = async () => {
        if (!question) return;
        setIsAsking(true);
        setAnswer('');
        const result = await geminiService.answerQuestion(question, documents);
        setAnswer(result);
        setIsAsking(false);
    };

    return (
        <div>
            <h2 className="text-3xl font-bold text-white mb-2">Team Q&A</h2>
            <p className="text-gray-400 mb-6">Ask a question, and Gemini will answer using the knowledge in your team's documents.</p>
            <div className="flex gap-2 mb-6">
                <input type="text" value={question} onChange={e => setQuestion(e.target.value)} placeholder="What is the Q3 marketing budget?" className="flex-grow bg-gray-800 rounded-md border-gray-700 px-4 py-2 focus:ring-teal-500 focus:border-teal-500" />
                <button onClick={handleAsk} disabled={isAsking} className="px-4 py-2 bg-teal-600 hover:bg-teal-700 rounded-md flex items-center gap-2 disabled:bg-gray-500"><QandAIcon className="h-5 w-5" /> Ask</button>
            </div>
            <div>
                {isAsking && <div className="flex items-center gap-2 text-gray-400"><Spinner /> Thinking...</div>}
                {answer && (
                    <div className="bg-gray-800 p-4 rounded-md prose prose-invert max-w-none">
                        <p className="whitespace-pre-wrap">{answer}</p>
                    </div>
                )}
            </div>
        </div>
    );
};

const VersionHistory: React.FC<{ history: Version[] }> = ({ history }) => {
    return (
        <ul className="space-y-4 max-h-96 overflow-y-auto">
            {[...history].reverse().map(version => (
                <li key={version.version} className="border border-gray-700 p-3 rounded-md">
                    <p className="font-semibold text-white">Version {version.version}</p>
                    <p className="text-sm text-gray-400">Created on: {version.createdAt.toLocaleString()}</p>
                </li>
            ))}
        </ul>
    );
};

export default App;